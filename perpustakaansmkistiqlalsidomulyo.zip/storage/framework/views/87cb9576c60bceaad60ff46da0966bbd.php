<form class="form-inline navbar-search mb-3" action="<?php echo e($url ?? url()->current()); ?>" method="GET">
    <div class="input-group w-100">
        <input type="text" name="search" value="<?php echo e(request()->query('search')); ?>" class="form-control"
            placeholder="<?php echo e($placeholder ?? 'Cari...'); ?>" aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
            <button class="btn btn-primary" type="submit">
                <i class="fas fa-search fa-sm"></i>
            </button>
        </div>
    </div>
</form>
<?php /**PATH C:\xampp\htdocs\perpustakaan-main\resources\views/components/admin/search.blade.php ENDPATH**/ ?>