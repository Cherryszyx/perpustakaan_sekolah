import "./bootstrap";
import "bootstrap";
import "../sass/app.scss";
import Alpine from "alpinejs";
window.Alpine = Alpine;
Alpine.start();
